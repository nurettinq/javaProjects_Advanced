package kitap;

import static kitap.KitapIslemler.menu;

public class Main {
    public static void main(String[] args) {
        menu();
    }
}
